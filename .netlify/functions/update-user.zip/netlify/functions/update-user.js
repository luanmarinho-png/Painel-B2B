// netlify/functions/update-user.js
var SUPABASE_URL = "https://cvwwucxjrpsfoxarsipr.supabase.co";
var SERVICE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN2d3d1Y3hqcnBzZm94YXJzaXByIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3NTMwMjEzOCwiZXhwIjoyMDkwODc4MTM4fQ.M6ZGpySPaj1ecL9rXS3q9UM4FnfD6Cz3eA0tFWqHi4c";
exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
      },
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }
  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
  }
  const { email, role, instituicao, ativo, nome } = body;
  if (!email) {
    return { statusCode: 400, body: JSON.stringify({ error: "Campo email \xE9 obrigat\xF3rio" }) };
  }
  try {
    const listResp = await fetch(
      `${SUPABASE_URL}/auth/v1/admin/users?page=1&per_page=1000`,
      {
        headers: {
          "apikey": SERVICE_KEY,
          "Authorization": `Bearer ${SERVICE_KEY}`
        }
      }
    );
    const listData = await listResp.json();
    const user = (listData.users || []).find((u) => u.email === email);
    if (user) {
      const updateResp = await fetch(`${SUPABASE_URL}/auth/v1/admin/users/${user.id}`, {
        method: "PUT",
        headers: {
          "apikey": SERVICE_KEY,
          "Authorization": `Bearer ${SERVICE_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          user_metadata: {
            ...user.user_metadata,
            role: role !== void 0 ? role : user.user_metadata?.role,
            instituicao: instituicao !== void 0 ? instituicao : user.user_metadata?.instituicao,
            nome: nome !== void 0 ? nome : user.user_metadata?.nome
          },
          // Se inativo, banir o usuário no Auth também
          ...ativo === false ? { ban_duration: "876600h" } : { ban_duration: "none" }
        })
      });
      if (!updateResp.ok) {
        const errData = await updateResp.json();
        console.error("Erro ao atualizar Auth:", errData);
      }
    }
    const updateFields = {};
    if (role !== void 0) updateFields.role = role;
    if (instituicao !== void 0) updateFields.instituicao = instituicao;
    if (ativo !== void 0) updateFields.ativo = ativo;
    if (nome !== void 0) updateFields.nome = nome;
    const whitelistResp = await fetch(
      `${SUPABASE_URL}/rest/v1/usuarios_autorizados?email=eq.${encodeURIComponent(email)}`,
      {
        method: "PATCH",
        headers: {
          "apikey": SERVICE_KEY,
          "Authorization": `Bearer ${SERVICE_KEY}`,
          "Content-Type": "application/json",
          "Prefer": "return=representation"
        },
        body: JSON.stringify(updateFields)
      }
    );
    const whitelistData = await whitelistResp.json();
    if (!whitelistResp.ok) {
      return { statusCode: 400, body: JSON.stringify({ error: "Erro na whitelist: " + JSON.stringify(whitelistData) }) };
    }
    return {
      statusCode: 200,
      body: JSON.stringify({ success: true, message: `Usu\xE1rio ${email} atualizado com sucesso!` })
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: "Erro interno: " + err.message }) };
  }
};
