// netlify/functions/deploy-ies.js
var crypto = require("crypto");
var NETLIFY_TOKEN = process.env.NETLIFY_TOKEN;
var SITE_ID = process.env.NETLIFY_SITE_ID;
var API = "https://api.netlify.com/api/v1";
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization"
};
var ok = (b) => ({ statusCode: 200, headers: { ...CORS, "Content-Type": "application/json" }, body: JSON.stringify(b) });
var err = (m, c = 500) => ({ statusCode: c, headers: { ...CORS, "Content-Type": "application/json" }, body: JSON.stringify({ error: m }) });
exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers: CORS, body: "" };
  if (event.httpMethod !== "POST") return err("Method not allowed", 405);
  if (!NETLIFY_TOKEN || !SITE_ID) {
    return err("Configure NETLIFY_TOKEN e NETLIFY_SITE_ID em Netlify \u2192 Site Settings \u2192 Environment Variables.");
  }
  let files;
  try {
    ({ files } = JSON.parse(event.body));
  } catch {
    return err("JSON inv\xE1lido no body", 400);
  }
  if (!files || typeof files !== "object" || Object.keys(files).length === 0) {
    return err('Campo "files" obrigat\xF3rio: { "path": "base64" }', 400);
  }
  try {
    const pathToSha = {};
    const shaToBuffer = {};
    for (const [raw, b64] of Object.entries(files)) {
      const p = raw.startsWith("/") ? raw : "/" + raw;
      const buf = Buffer.from(b64, "base64");
      const sha = crypto.createHash("sha1").update(buf).digest("hex");
      pathToSha[p] = sha;
      shaToBuffer[sha] = buf;
    }
    const deploysResp = await fetch(`${API}/sites/${SITE_ID}/deploys?per_page=1`, {
      headers: { Authorization: `Bearer ${NETLIFY_TOKEN}` }
    });
    if (!deploysResp.ok) throw new Error(`Deploys: ${deploysResp.status}`);
    const currentDeploy = (await deploysResp.json())[0];
    const mergedFiles = { ...pathToSha };
    if (currentDeploy?.id) {
      const r = await fetch(`${API}/deploys/${currentDeploy.id}/files`, {
        headers: { Authorization: `Bearer ${NETLIFY_TOKEN}` }
      });
      if (r.ok) {
        for (const f of await r.json()) {
          if (!mergedFiles[f.id]) mergedFiles[f.id] = f.sha;
        }
      }
    }
    const createResp = await fetch(`${API}/sites/${SITE_ID}/deploys`, {
      method: "POST",
      headers: { Authorization: `Bearer ${NETLIFY_TOKEN}`, "Content-Type": "application/json" },
      body: JSON.stringify({ files: mergedFiles, draft: false })
    });
    if (!createResp.ok) {
      const txt = await createResp.text();
      throw new Error(`Criar deploy: ${createResp.status} \u2014 ${txt}`);
    }
    const deploy = await createResp.json();
    const required = deploy.required || [];
    if (required.length > 0) {
      await Promise.all(required.map(async (sha) => {
        const buf = shaToBuffer[sha];
        if (!buf) return;
        const p = Object.keys(pathToSha).find((k) => pathToSha[k] === sha);
        if (!p) return;
        const up = await fetch(`${API}/deploys/${deploy.id}/files${p}`, {
          method: "PUT",
          headers: { Authorization: `Bearer ${NETLIFY_TOKEN}`, "Content-Type": "application/octet-stream" },
          body: buf
        });
        if (!up.ok) throw new Error(`Upload ${p}: ${up.status}`);
      }));
    }
    return ok({
      success: true,
      deploy_id: deploy.id,
      state: deploy.state,
      url: deploy.ssl_url || deploy.url,
      files_new: Object.keys(pathToSha).length,
      files_total: Object.keys(mergedFiles).length,
      files_uploaded: required.length
    });
  } catch (e) {
    return err(e.message);
  }
};
